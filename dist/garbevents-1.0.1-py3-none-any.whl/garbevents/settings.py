# -*- coding: utf-8 -*-
# @Time    : 2020/6/20 18:57
# @Author  : 李佳玮
# @Email   : lijiawei@symbio.com
# @File    : settings.py
# @Software: PyCharm


class Settings(object):
    report_path = None
    url = None
    all_events = []
