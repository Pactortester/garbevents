__version__ = "2.0.5"
__description__ = "grabbing buried points tools. Created: Lijiawei. Version {}".format(__version__)
"""
This is a python toolkit for real-time capture,
analysis, cleaning and report generation of embedded points based on the development of mitmproxy.

"""